SortList :: SortList()		// Constructor to initialize node values
{
	Data='\0';
	Occurance=0;
	Link=NULL;
	Lchild=NULL;
	Rchild=NULL;
}

/* Creating new node       */

SortList * SortList :: NewNode(unsigned char Data, long Occurance)   
{
	SortList *temp;
	temp=new(SortList);					// Memory Allocation 
	temp->Data = Data;
	temp->Occurance =Occurance;
	return temp;
}

/* Inserting the node in List */

SortList *  SortList :: InsertList(SortList *temp)
{
	SortList *DupHead;
	DupHead = Head;

   	if (Head == NULL || Head->Occurance > temp->Occurance)           //Check for Null node 
	{
		Head =temp;
		Head->Link=DupHead;
		return Head;
	}
	else
	{
	    while(DupHead !=NULL)
		{
			if( DupHead->Occurance <= temp->Occurance && (DupHead->Link ==NULL || DupHead->Link->Occurance > temp->Occurance  ))    // Searching its Position
			{
				temp->Link=DupHead->Link;
				DupHead->Link=temp;
				return Head;
			}	
			DupHead =DupHead->Link;   // Traversing the List still the new node find its position
		}
		DupHead->Link=temp;
	}
	return Head;
}

/* Display the contents of the list */

void SortList :: DispList()			
{
	SortList *DupHead;

	DupHead=Head;
	while(DupHead !=NULL)
	{
		cout << DupHead->Data << " = " << DupHead->Occurance << " ---> ";
		DupHead=DupHead->Link;
	}
}

/* Constructing Tree Node */

SortList* SortList :: InsertTree()			
{
	SortList *temp;
	SortList *DupHead;
	
	DupHead=Head;
	temp = new (SortList);				// Memory Allocation
	temp->Data='~';
	temp->Occurance = DupHead->Occurance +DupHead->Link->Occurance;   // Root node's Occurance should be the sum of the children's Occurances
	temp->Lchild=new(SortList);			// Memory Allocation
	temp->Lchild =DupHead;
	temp->Rchild =new(SortList);  		              // Memory Allocation
	temp->Rchild=DupHead->Link;
	return temp;
}

/* Huffman Tree is used to construct the Table */

void HuffmanTree (SortList *T,int Direction)
{
	static int nbits=1;				// To count no of bits
	static int Val=0;				
	int shiftVal=0;				// To get the unique value 
	if (T !=NULL)
	{
		Val |= Direction;
		if (T->Lchild ==NULL && T->Rchild ==NULL)    // We need only leaf 
		{
			shiftVal=Val<<(8-nbits);
			cout << '\t' << T->Data << '\t' << T->Occurance << '\t' <<nbits << '\t' <<"Value = " << Val << '\t' << "Shift Value = " << shiftVal <<endl;
			if(nbits < Min_BitSize)
				Min_BitSize=nbits;		// To get Minimum bit size
			Thead[T->Data].Data =T->Data; 
			Thead[T->Data].Occurance =T->Occurance ;
			Thead[T->Data].Nbits =nbits;
			Thead[T->Data].Bvalue =shiftVal;
		}
		nbits++;			// Increase the no of bit count when traversing left side
		Val<<=1;
		HuffmanTree(T->Lchild,0);
		nbits++;			// Increase the no of bit count when traversing right side
		Val<<=1;
		HuffmanTree(T->Rchild,1);
	}
	nbits--;				// Decrease the no of bit count when back track 
	Val>>=1;
}

/* Display the Final Table */

void Table ::DispTable()
{
	int i;
	for (i=0;i<255;i++)
		if(Thead[i].Occurance !=0)
			cout << Thead[i].Data <<"\t"<<Thead[i].Occurance <<"\t"<<Thead[i].Nbits <<"\t"<<Thead[i].Bvalue <<endl;
}

/* Initialize the File Compress Object */

FileCompress :: FileCompress()
{
	Read='\0';
}

/* Reading the character from the Original File */

void FileCompress ::Compress(char *FStr)
{
	char i;
	while (*FStr != '\0')				// Read the character
	{
		i=*FStr;
		Do_Compress(*FStr++,Thead[i].Nbits,Thead[i].Bvalue);   //Call the Do_Compress with the following arguments Character, No. of Bits and Shift value
		str++;
	}
	CompStr[charcount]='\0';
}

/* Compressing the file */

void FileCompress ::Do_Compress(char Read,int Nbits, int shftval)
{
	static int k;
	int Compval=128;
	int j,flag;
	static unsigned char wchar='\0';
	for(;k<8;)
	{
		for(j=0;j<Nbits;j++)
		{
			wchar |=(shftval & Compval)?1:0;		//Get the compressed character 
			Compval>>=1;
			flag=1;
			k++;
			if(k==8)
			{
				cout << wchar;
				CompStr[charcount]=wchar;	//Store the compressed character in the compressed file
				charcount++;
				flag=0;
				wchar ='\0';
				k=0;
				Compval=128;
				Compval>>=(j+1);
			}
					// For Last Character we should write
			wchar <<=1;
		}
		if (flag==1 && *str=='\0')
		{
			while(Compval !=0)
			{
				wchar<<=1;
				Compval>>=1;
			}
			CompStr[charcount]=wchar;
		}
		break;
	}
}

/* Decompress Function */

void FileCompress::Do_Decompress(unsigned char *DStr)
{
	int j=0;
	int Compval;
	int i,k,flag;
	static unsigned char Rchar='\0';
	while(*DStr !='\0')
	{
		Compval=128;
		for(k=0;k<8;k++)
		{
			Rchar|=(*DStr & Compval) ? 1:0;	// Get the decompressed character from the compressed file
			Compval>>=1;
			j++;
			flag=1;
			if (j >=Min_BitSize)	// Check the bit size with Minimum bit size
			{
				Rchar <<=(8-j);
				for(i=0;i<255;i++)
				{
					if(j==Thead[i].Nbits && Rchar==Thead[i].Bvalue)		// Check the bit size and shift value with table datas
					{
						cout << Thead[i].Data ;
						Rchar ='\0';
						j=0; flag=0;
						break;
					}
				}
				if(flag==1)
					Rchar >>=(8-j);
			}
			Rchar <<=1;
		}
		*DStr++;
	}
}
