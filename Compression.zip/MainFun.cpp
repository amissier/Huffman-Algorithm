#include "Decl.h"
#include "Fun.h"


/* Main Function */

void main()								
{
  	  long AlphaNum[255]; unsigned char i;
	SortList L,*H,*temp;
	Table M;
	FileCompress fp;
	char *Str;
	Str=str;
	for(i=0;i<255;i++)		// Initializing to zero for all characters
		AlphaNum[i]=0;
    
	while (*Str != '\0')  // Reading the file still eof and count the occurance for each character
		AlphaNum[*Str++] +=1;
		
   	 for(i=0;i<255;i++)
		if (AlphaNum[i] !=0) 
		{
			cout << char(i) << " -> " << AlphaNum[i] << endl;
			temp=L.NewNode(char(i),AlphaNum[i]);	// Call the new node create function
			H=L.InsertList(temp);	// Insert the new node into Sorted Order List	
		}
	 cout<< "List Contents" << endl;
 	   L.DispList();		// Call the function which is used to display the List content
	 cout <<endl<<"Tree Construction" << endl;
	 while(Head ->Link !=NULL)							
	 {
		H=L.InsertTree ();
		Head=Head->Link->Link;
		H=L.InsertList(H);	// Call the Huffman Tree construction function
		L.DispList();
		cout<<endl;
	 }	
	 cout << "Display from Tree" <<endl;
	 HuffmanTree (Head,0);	    // Call the function which is used to display the Huffman Tree
	 cout << endl;
	 delete Head;
	 cout << "Display from Table" << endl;
	 M.DispTable();		    // Call the function which is used to display the final Table
	 cout<< endl;
	 fp.Compress(str); 
	 cout<< endl;
	 cout << CompStr;
	 cout <<endl;
	 fp.Do_Decompress(CompStr);
	 cout << endl;
}


