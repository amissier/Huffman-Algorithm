#include <iostream.h>
#include <string.h>
#include <conio.h>

char *str=" _ 985 aaabb 3414151SFG";	// Example String
unsigned char CompStr[100];			// Compressed String Variable
int charcount;			// This count is used to increase the index for the compressed string
int Min_BitSize=8;		// Minimum bit Size, it should be less than or equal to 8

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*			Class for Sorted Order List			         												   */
/* It is containg the character,their Occurance  Left and Right Link, The methods are NewNode              */
/* used to construct the new node, InsertList is used to insert the new node in its position,  	           */
/* InsertTree is used to construct Final Huffman Tree, Huffman Tree is used to construct the	           */
/* Table which is used for Comprssion.			 														   */ 
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

class SortList
{
protected:
	unsigned char Data;
	long Occurance;  
	SortList * Lchild;
	SortList * Rchild;
public:
	SortList * Link;
	SortList();
	SortList * NewNode(unsigned char,long);
	SortList * InsertList(SortList *);
	SortList * InsertTree();
	void DispList();
	friend void HuffmanTree(SortList *, int);
};


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */ 
/*					Class for Table				  														   */
/* This is used to store the character, their Occurance, No of Bits required for compression			   */
/* and value for that characters																		   */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

class Table 
{
public:
	unsigned char Data;
	long Occurance;
	int Nbits;
	unsigned char Bvalue;
	void DispTable();
};

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*		                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         